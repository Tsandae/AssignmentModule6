library(keras)
library(tensorflow)

# Load and preprocess data
fashion_mnist <- dataset_fashion_mnist()
x_train <- fashion_mnist$train$x
y_train <- fashion_mnist$train$y
x_test <- fashion_mnist$test$x
y_test <- fashion_mnist$test$y

# Reshape the input data to (28, 28, 1) and normalize it to range [0, 1]
x_train <- array_reshape(x_train, c(dim(x_train)[1], 28, 28, 1)) / 255
x_test <- array_reshape(x_test, c(dim(x_test)[1], 28, 28, 1)) / 255

# One-hot encode the labels
y_train <- to_categorical(y_train, 10)
y_test <- to_categorical(y_test, 10)

# Build the model
model <- keras_model_sequential() %>%
  # Add Conv2D layers
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu", input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  # Flatten and add Dense layers
  layer_flatten() %>%
  layer_dense(units = 128, activation = "relu") %>%
  layer_dropout(rate = 0.5) %>%
  # Output layer
  layer_dense(units = 10, activation = "softmax")
# Compile the model
model %>% compile(
  loss = "categorical_crossentropy",
  optimizer = optimizer_adam(),
  metrics = c("accuracy")
)

# Train the model
model %>% fit(
  x_train, y_train,
  batch_size = 128,
  epochs = 10,
  validation_data = list(x_test, y_test)
)

# Evaluate the model
evaluation <- model %>% evaluate(x_test, y_test, verbose = 0)
cat(sprintf("Test Accuracy: %.2f\n", evaluation$accuracy))

# Make predictions for two images
sample_images <- x_test[1:2,,,drop = FALSE]
sample_labels <- y_test[1:2,]
predictions <- model %>% predict(sample_images)

# Plot the results
class_names <- c(
  "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
  "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
)

par(mfrow = c(1, 2))  # Set up plotting layout
for (i in 1:2) {
  image <- sample_images[i,,,1]
  true_label <- class_names[which.max(sample_labels[i,])]
  predicted_label <- class_names[which.max(predictions[i,])]
  
  # Plot the image and prediction
  image(matrix(image, nrow = 28, ncol = 28), col = gray.colors(256), main = paste0(
    "True Label: ", true_label, "\nPredicted: ", predicted_label
  ))
}
